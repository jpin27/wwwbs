/* Placeholder file */

This folder will contain the images we're gonna use for the website.
