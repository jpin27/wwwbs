<?php

?>

<html>
 <head>
  <title>Wacky Waving Wellness Booking System</title>
  <link rel="stylesheet" type="text/css" href="styles/styles.css" />
 </head>
 <body>
  <div id="container">
     <div id="header">
         <h1>Wacky Waving Wellness Centre</h1>
     </div>

	  <h2 style="color: #777">Practitioner Bookings</h2>
	  <h3 style="color: #777">Edit Booking</h3>
	  <form>
	 Brief Description: <br>
	 <input type="text" style="width: 95%;font-size: 20px;padding: .4em;line-height: 1.4em;"><br>
	 <p></p>
	 Full Description: (optional)<br>
	 <textarea name="Description" rows="10" cols="40" style="margin: 0px 24.2188px 0px 0px; height: 108px; width: 1208px; font-size: 20px"></textarea>
	 
	 <input type="submit" value="Save" class="button">
	 </form>
	 <nav>
            <ul>
           <li> <a href="#">Log In</a></li>
           <li><a href="index.php">Search Practitioners</a></li>
           <li> <a href="booking.php">My Bookings</a></li>
            </ul>
            </nav>

	<div id="footer">
		<ul>
		<a href="#">Contact</a>
		<a href="#">Feedback</a>
		</ul>
		<ul>
		<a href="#">Disclaimer</a>
		<a href="#">Privacy</a>
		&copy;Wacky Waving Wellnes Booking Center
		</ul>
	</div>
	 </div>
 </body>
 
</html>